// Programming‑by‑Demonstration helper for Stretch web interface


/**
 * Saved poses.  Each entry is
 * {
 *   name: string,                   // user‑provided label
 *   frame: 'world'|'base'|'marker', // frame selected at save time
 *   joints: { yaw,pitch,roll,lift,arm }, // raw joint snapshot (deg / m)
 *   tf: ROSLIB.Transform | null     // full TF transform of grasp center in chosen frame
 * }
 */
export const savedPoses = [];

// Persisting between page refreshes
const LS_KEY = 'stretch_saved_poses_v1';

// --------------------------
// INITIALISATION
// --------------------------

export function initPBD() {
  loadFromStorage();
  renderPoseList();
}

// Call once rosbridge is connected
window.addEventListener('ros_ready', () => {
  // Create a TF client so we can capture EE pose in arbitrary frames
  window.tfClient = new ROSLIB.TFClient({
    ros: window.ros,
    fixedFrame: 'fk_link_mast', // world‑ish frame; will change dynamically when capturing
    angularThres: 0.01,
    transThres: 0.01,
    rate: 10.0,
  });
});

// --------------------------
// CAPTURE ––––––––––––––––––
// --------------------------

/**
 * Saves the current arm pose.
 * Prompts the user for a name + frame and updates UI and localStorage.
 */
export function saveCurrentPose() {
  const defaultName = `pose_${savedPoses.length + 1}`;
  const name = prompt('Name for this pose:', defaultName);
  if (!name) return;

  const frame = prompt(
    "Coordinate frame?\n- 'world' for fk_link_mast\n- 'base' for link_base\n- or enter the frame_id of an ArUco marker",
    'world'
  );
  if (!frame) return;

  // Snapshot joints already maintained by robotController.js
  const joints = {
    yaw: currentJointPositions['yaw'],
    pitch: currentJointPositions['pitch'],
    roll: currentJointPositions['roll'],
    lift: currentControlPositions['lift'],
    arm: currentControlPositions['arm'],
  };

  // Capture TF transform of grasp center in selected frame (best‑effort)
  let tfTransform = null;
  if (window.tfClient) {
    tfTransform = awaitTransform(frame, 'link_grasp_center');
  }

  savedPoses.push({ name, frame, joints, tf: tfTransform });
  persist();
  renderPoseList();
}

// Helper – wait one TF update
function awaitTransform(targetFrame, sourceFrame) {
  return new Promise((resolve) => {
    const listener = new ROSLIB.TFClient({
      ros: window.ros,
      fixedFrame: targetFrame,
      rate: 10.0,
    });
    listener.subscribe(sourceFrame, (tf) => {
      listener.unsubscribe(sourceFrame);
      resolve(tf);
    });
  });
}

// --------------------------
// PLAYBACK –––––––––––––––––
// --------------------------

export function playSequence() {
  if (savedPoses.length === 0) {
    alert('No poses stored.');
    return;
  }
  let delay = 0;
  savedPoses.forEach((pose, idx) => {
    setTimeout(() => {
      executeFollowJointTrajectory(
        ['joint_wrist_yaw', 'joint_wrist_pitch', 'joint_wrist_roll', 'joint_lift', 'wrist_extension'],
        [pose.joints.yaw, pose.joints.pitch, pose.joints.roll, pose.joints.lift, pose.joints.arm]
      );
      console.log(`Executing pose #${idx + 1} – ${pose.name}`);
    }, delay);
    delay += 3000; // 3‑s between poses; adjust as needed
  });
}

export function goToPose(index) {
  const pose = savedPoses[index];
  executeFollowJointTrajectory(
    ['joint_wrist_yaw', 'joint_wrist_pitch', 'joint_wrist_roll', 'joint_lift', 'wrist_extension'],
    [pose.joints.yaw, pose.joints.pitch, pose.joints.roll, pose.joints.lift, pose.joints.arm]
  );
  console.log('Sent robot to pose:', pose.name);
}

export function clearPoses() {
  if (!confirm('Delete all saved poses?')) return;
  savedPoses.length = 0;
  persist();
  renderPoseList();
}

// --------------------------
// UI BINDINGS ––––––––––––––
// --------------------------

function renderPoseList() {
  const container = document.getElementById('poseList');
  if (!container) return;
  container.innerHTML = '';
  savedPoses.forEach((pose, idx) => {
    const li = document.createElement('li');
    li.textContent = `${idx + 1}. ${pose.name}  [${pose.frame}]`;
    li.style.cursor = 'pointer';
    li.onclick = () => goToPose(idx);
    container.appendChild(li);
  });
}

// --------------------------
// STORAGE ––––––––––––––––––
// --------------------------

function persist() {
  localStorage.setItem(LS_KEY, JSON.stringify(savedPoses));
}

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      savedPoses.push(...arr);
    }
  } catch (e) {
    console.warn('Could not load saved poses:', e);
  }
}

// --------------------------
// OPTIONAL: expose for console debugging
// --------------------------
window.PBD = { saveCurrentPose, playSequence, clearPoses, goToPose, savedPoses };
