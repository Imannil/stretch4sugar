import json, math, rclpy, pathlib
from rclpy.node import Node
from tf2_ros import Buffer, TransformListener
from geometry_msgs.msg import Twist
from std_srvs.srv import Trigger

POSE_FILE = pathlib.Path.home() / './Desktop/stretch_saved_poses.json'

class PosePlayer(Node):
    def __init__(self):
        super().__init__('pose_player')
        self.poses = json.loads(POSE_FILE.read_text())
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.create_service(Trigger, '/pose_player', self.play_cb)
        self.base_pub = self.create_publisher(Twist, '/stretch/cmd_vel', 10)
        self.get_logger().info('PosePlayer ready')

    def play_cb(self, _, response):
        for p in self.poses:
            target = self.tf_buffer.transform(
                self._dict_to_tf(p),
                'base_link')                 # re‑express in current base frame

            self._goto(target)                   # simple heuristic move
        response.success = True
        response.message = 'Sequence complete'
        return response

    # helper: turn dict back into TransformStamped
    def _dict_to_tf(self, d):
        from tf2_geometry_msgs import PoseStamped
        tf = PoseStamped()
        tf.header.frame_id = d['frame']
        tf.pose.position.x = d['transform']['translation']['x']
        tf.pose.position.y = d['transform']['translation']['y']
        tf.pose.position.z = d['transform']['translation']['z']
        # print(tf)
        return tf

    def _goto(self, tf):
        # heuristic: yaw ≈ atan2(y,x), arm ≈ y, lift ≈ z
        # publish Twist or use your existing executeFollowJointTrajectory helper
        pass

def main():
    rclpy.init()
    node = PosePlayer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()

if __name__ == '__main__':
    main()
# use the pose's x to move the base, z to move the lift, and y to extend the arm).
